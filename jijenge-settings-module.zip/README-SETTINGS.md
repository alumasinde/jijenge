# Jijenge Settings Module

This module follows the existing Jijenge backend layout; it does not introduce a `Modules/` directory.

## Files

```text
backend/Settings/
├── DTOs/
├── Models/
├── Repositories/
├── Services/
├── Handlers/
├── Validators/
└── routes.go
```

## Migration

`backend/migrations/020_settings.sql`

The settings table stores controlled key/value configuration. Examples:

- `general.app_name`
- `general.tagline`
- `branding.logo_url`
- `branding.primary_color`
- `branding.secondary_color`
- `seo.site_title`
- `seo.meta_description`
- `seo.og_image_url`

Only settings explicitly marked `is_public = true` are returned by the public endpoint.

## Routes

Public:

```http
GET /api/v1/config/public
```

Authenticated administration endpoints:

```http
GET    /api/v1/admin/settings
PUT    /api/v1/admin/settings
DELETE /api/v1/admin/settings/{key}
```

The route registration deliberately uses the existing Auth middleware. Before production, wire the admin routes through the existing authorization permission middleware (for example a dedicated `settings.manage` permission) rather than authentication alone.

## Integration

In `Routes/web.go`, create:

```go
settingsRepo := SettingsRepositories.NewMySQLRepository(db)
settingsService := SettingsServices.New(settingsRepo)
settingsHandler := SettingsHandlers.New(settingsService)
Settings.RegisterRoutes(mux, settingsHandler, authn)
```

Use aliases as needed to match the existing import style.

## Important

This module intentionally does not add:

- a second database abstraction;
- a second authentication system;
- a second permission system;
- direct PHP/MySQL access;
- frontend CSS/theme logic in Go.

The Go API owns configuration data; PHP remains the presentation layer.
