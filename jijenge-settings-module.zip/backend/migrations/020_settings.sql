-- 020: database-backed application settings.
-- Settings are intentionally generic so branding/SEO/general configuration
-- can evolve without a migration for every new harmless setting.
CREATE TABLE IF NOT EXISTS settings (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    setting_key VARCHAR(128) NOT NULL,
    category VARCHAR(64) NOT NULL,
    setting_value TEXT NOT NULL,
    is_public BOOLEAN NOT NULL DEFAULT FALSE,
    created_at DATETIME(6) NOT NULL,
    updated_at DATETIME(6) NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_settings_key (setting_key),
    KEY idx_settings_public_category_key (is_public, category, setting_key)
) ENGINE=InnoDB;
