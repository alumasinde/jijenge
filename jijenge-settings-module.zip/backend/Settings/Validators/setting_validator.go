package Validators

import (
	"errors"
	"regexp"
	"strings"
)

var (
	ErrInvalidKey   = errors.New("invalid setting key")
	ErrInvalidValue = errors.New("invalid setting value")
)

var keyPattern = regexp.MustCompile(`^[a-z0-9]+(\.[a-z0-9_]+)+$`)

func ValidateKey(key string) error {
	key = strings.TrimSpace(key)
	if key == "" || len(key) > 128 || !keyPattern.MatchString(key) {
		return ErrInvalidKey
	}
	return nil
}

func ValidateValue(value string) error {
	if len(value) > 10000 {
		return ErrInvalidValue
	}
	return nil
}
