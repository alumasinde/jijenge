package Models

import "time"

type Setting struct {
	ID        uint64    `json:"id"`
	Key       string    `json:"key"`
	Category  string    `json:"category"`
	Value     string    `json:"value"`
	IsPublic  bool      `json:"is_public"`
	CreatedAt time.Time `json:"created_at"`
	UpdatedAt time.Time `json:"updated_at"`
}
