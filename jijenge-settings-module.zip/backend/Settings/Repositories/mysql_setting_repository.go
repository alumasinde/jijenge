package Repositories

import (
	"context"
	"database/sql"
	"errors"
	"time"

	"github.com/alumasinde/jijenge/Core/Database"
	"github.com/alumasinde/jijenge/Settings/Models"
)

type MySQLRepository struct {
	db *Database.DB
}

func NewMySQLRepository(db *Database.DB) *MySQLRepository {
	return &MySQLRepository{db: db}
}

func (r *MySQLRepository) Get(ctx context.Context, key string) (*Models.Setting, error) {
	const q = `SELECT id, setting_key, category, setting_value, is_public, created_at, updated_at
		FROM settings WHERE setting_key = ? LIMIT 1`

	var x Models.Setting
	err := r.db.QueryRowContext(ctx, q, key).Scan(
		&x.ID, &x.Key, &x.Category, &x.Value, &x.IsPublic, &x.CreatedAt, &x.UpdatedAt,
	)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, ErrNotFound
	}
	if err != nil {
		return nil, err
	}
	return &x, nil
}

func (r *MySQLRepository) List(ctx context.Context) ([]Models.Setting, error) {
	const q = `SELECT id, setting_key, category, setting_value, is_public, created_at, updated_at
		FROM settings ORDER BY category, setting_key`

	rows, err := r.db.QueryContext(ctx, q)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var result []Models.Setting
	for rows.Next() {
		var x Models.Setting
		if err := rows.Scan(&x.ID, &x.Key, &x.Category, &x.Value, &x.IsPublic, &x.CreatedAt, &x.UpdatedAt); err != nil {
			return nil, err
		}
		result = append(result, x)
	}
	if err := rows.Err(); err != nil {
		return nil, err
	}
	return result, nil
}

func (r *MySQLRepository) ListPublic(ctx context.Context) ([]Models.Setting, error) {
	const q = `SELECT id, setting_key, category, setting_value, is_public, created_at, updated_at
		FROM settings WHERE is_public = 1 ORDER BY category, setting_key`

	rows, err := r.db.QueryContext(ctx, q)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var result []Models.Setting
	for rows.Next() {
		var x Models.Setting
		if err := rows.Scan(&x.ID, &x.Key, &x.Category, &x.Value, &x.IsPublic, &x.CreatedAt, &x.UpdatedAt); err != nil {
			return nil, err
		}
		result = append(result, x)
	}
	if err := rows.Err(); err != nil {
		return nil, err
	}
	return result, nil
}

func (r *MySQLRepository) Upsert(ctx context.Context, setting *Models.Setting) error {
	const q = `INSERT INTO settings (setting_key, category, setting_value, is_public, created_at, updated_at)
		VALUES (?, ?, ?, ?, ?, ?)
		ON DUPLICATE KEY UPDATE
			category = VALUES(category),
			setting_value = VALUES(setting_value),
			is_public = VALUES(is_public),
			updated_at = VALUES(updated_at)`

	now := time.Now().UTC()
	if setting.CreatedAt.IsZero() {
		setting.CreatedAt = now
	}
	setting.UpdatedAt = now

	_, err := r.db.ExecContext(ctx, q,
		setting.Key, setting.Category, setting.Value, setting.IsPublic,
		setting.CreatedAt, setting.UpdatedAt,
	)
	return err
}

func (r *MySQLRepository) Delete(ctx context.Context, key string) error {
	res, err := r.db.ExecContext(ctx, `DELETE FROM settings WHERE setting_key = ?`, key)
	if err != nil {
		return err
	}
	n, err := res.RowsAffected()
	if err != nil {
		return err
	}
	if n == 0 {
		return ErrNotFound
	}
	return nil
}
