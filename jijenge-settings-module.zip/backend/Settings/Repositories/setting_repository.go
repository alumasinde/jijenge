package Repositories

import (
	"context"
	"errors"

	"github.com/alumasinde/jijenge/Settings/Models"
)

var (
	ErrNotFound = errors.New("setting not found")
	ErrExists   = errors.New("setting already exists")
)

type Repository interface {
	Get(ctx context.Context, key string) (*Models.Setting, error)
	List(ctx context.Context) ([]Models.Setting, error)
	ListPublic(ctx context.Context) ([]Models.Setting, error)
	Upsert(ctx context.Context, setting *Models.Setting) error
	Delete(ctx context.Context, key string) error
}
