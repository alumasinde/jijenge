package Settings

import (
	"net/http"

	"github.com/alumasinde/jijenge/Auth/Middleware"
	"github.com/alumasinde/jijenge/Settings/Handlers"
	"github.com/alumasinde/jijenge/Settings/Services"
)

func RegisterRoutes(mux *http.ServeMux, handler *Handlers.Handler, authn *Middleware.Authenticator) {
	mux.HandleFunc("GET /api/v1/config/public", handler.Public)

	if authn == nil {
		return
	}

	mux.Handle("GET /api/v1/admin/settings", authn.Require(http.HandlerFunc(handler.List)))
	mux.Handle("PUT /api/v1/admin/settings", authn.Require(http.HandlerFunc(handler.Upsert)))
	mux.Handle("DELETE /api/v1/admin/settings/{key}", authn.Require(http.HandlerFunc(handler.Delete)))

	_ = Services.New
}
