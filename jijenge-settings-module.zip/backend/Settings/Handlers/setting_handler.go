package Handlers

import (
	"encoding/json"
	"errors"
	"net/http"
	"strings"

	"github.com/alumasinde/jijenge/Core/HTTP"
	"github.com/alumasinde/jijenge/Settings/DTOs"
	"github.com/alumasinde/jijenge/Settings/Repositories"
	"github.com/alumasinde/jijenge/Settings/Services"
	"github.com/alumasinde/jijenge/Settings/Validators"
)

type Handler struct {
	Service *Services.Service
}

func New(service *Services.Service) *Handler {
	return &Handler{Service: service}
}

func (h *Handler) Public(w http.ResponseWriter, r *http.Request) {
	items, err := h.Service.Public(r.Context())
	if err != nil {
		HTTP.ErrorResponse(w, http.StatusInternalServerError, "SETTINGS_UNAVAILABLE", "Unable to load public settings")
		return
	}

	out := make([]DTOs.PublicSetting, 0, len(items))
	for _, item := range items {
		out = append(out, DTOs.PublicSetting{Key: item.Key, Value: item.Value})
	}
	HTTP.JSON(w, http.StatusOK, DTOs.SettingsResponse{Settings: out})
}

func (h *Handler) List(w http.ResponseWriter, r *http.Request) {
	items, err := h.Service.All(r.Context())
	if err != nil {
		HTTP.ErrorResponse(w, http.StatusInternalServerError, "SETTINGS_UNAVAILABLE", "Unable to load settings")
		return
	}
	HTTP.JSON(w, http.StatusOK, items)
}

func (h *Handler) Upsert(w http.ResponseWriter, r *http.Request) {
	var req DTOs.UpdateSetting
	decoder := json.NewDecoder(r.Body)
	decoder.DisallowUnknownFields()
	if err := decoder.Decode(&req); err != nil {
		HTTP.ErrorResponse(w, http.StatusBadRequest, "INVALID_JSON", "Invalid request body")
		return
	}

	key := strings.TrimSpace(req.Key)
	if err := Validators.ValidateKey(key); err != nil {
		HTTP.ErrorResponse(w, http.StatusBadRequest, "INVALID_SETTING_KEY", "Invalid setting key")
		return
	}
	if err := Validators.ValidateValue(req.Value); err != nil {
		HTTP.ErrorResponse(w, http.StatusBadRequest, "INVALID_SETTING_VALUE", "Invalid setting value")
		return
	}

	public := false
	if req.IsPublic != nil {
		public = *req.IsPublic
	} else if existing, err := h.Service.Repo.Get(r.Context(), key); err == nil {
		public = existing.IsPublic
	} else if !errors.Is(err, Repositories.ErrNotFound) {
		HTTP.ErrorResponse(w, http.StatusInternalServerError, "SETTINGS_UNAVAILABLE", "Unable to load setting")
		return
	}

	item, err := h.Service.Upsert(r.Context(), key, req.Value, public)
	if err != nil {
		HTTP.ErrorResponse(w, http.StatusBadRequest, "INVALID_SETTING", "Unable to update setting")
		return
	}
	HTTP.JSON(w, http.StatusOK, item)
}

func (h *Handler) Delete(w http.ResponseWriter, r *http.Request) {
	key := strings.TrimSpace(r.PathValue("key"))
	if err := Validators.ValidateKey(key); err != nil {
		HTTP.ErrorResponse(w, http.StatusBadRequest, "INVALID_SETTING_KEY", "Invalid setting key")
		return
	}
	if err := h.Service.Delete(r.Context(), key); err != nil {
		if errors.Is(err, Repositories.ErrNotFound) {
			HTTP.ErrorResponse(w, http.StatusNotFound, "SETTING_NOT_FOUND", "Setting not found")
			return
		}
		HTTP.ErrorResponse(w, http.StatusInternalServerError, "SETTING_DELETE_FAILED", "Unable to delete setting")
		return
	}
	w.WriteHeader(http.StatusNoContent)
}
