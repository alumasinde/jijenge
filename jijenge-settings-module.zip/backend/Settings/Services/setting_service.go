package Services

import (
	"context"
	"strings"

	"github.com/alumasinde/jijenge/Settings/Models"
	"github.com/alumasinde/jijenge/Settings/Repositories"
	"github.com/alumasinde/jijenge/Settings/Validators"
)

type Service struct {
	Repo Repositories.Repository
}

func New(repo Repositories.Repository) *Service {
	return &Service{Repo: repo}
}

func (s *Service) Public(ctx context.Context) ([]Models.Setting, error) {
	return s.Repo.ListPublic(ctx)
}

func (s *Service) All(ctx context.Context) ([]Models.Setting, error) {
	return s.Repo.List(ctx)
}

func (s *Service) Upsert(ctx context.Context, key, value string, public bool) (*Models.Setting, error) {
	key = strings.TrimSpace(key)
	if err := Validators.ValidateKey(key); err != nil {
		return nil, err
	}
	if err := Validators.ValidateValue(value); err != nil {
		return nil, err
	}

	category := key
	if i := strings.IndexByte(key, '.'); i > 0 {
		category = key[:i]
	}

	x := &Models.Setting{
		Key:      key,
		Category: category,
		Value:    value,
		IsPublic: public,
	}
	if err := s.Repo.Upsert(ctx, x); err != nil {
		return nil, err
	}
	return x, nil
}

func (s *Service) Delete(ctx context.Context, key string) error {
	if err := Validators.ValidateKey(key); err != nil {
		return err
	}
	return s.Repo.Delete(ctx, key)
}
