package DTOs

type UpdateSetting struct {
	Key      string `json:"key"`
	Value    string `json:"value"`
	IsPublic *bool  `json:"is_public,omitempty"`
}

type PublicSetting struct {
	Key   string `json:"key"`
	Value string `json:"value"`
}

type SettingsResponse struct {
	Settings []PublicSetting `json:"settings"`
}
